"""
URL configuration for backend project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
    SpectacularRedocView,
)


urlpatterns = [
    path('admin/', admin.site.urls),
    path("user/", include("apps.accounts.urls")),
    path('api/product/',include("apps.adminside.product.urls")),
    path('api/order/', include("apps.userside.order.urls")),
    path('api/orders/', include("apps.adminside.orders.urls")),
    path('api/cart/', include("apps.userside.cart.urls")),
    path('api/user/', include("apps.adminside.users.urls")),
    path('api/dashboard/', include("apps.adminside.dashboard.urls")),
    
    path('api/schema/',    SpectacularAPIView.as_view(),        name='schema'),
    path('api/docs/',      SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/redoc/',     SpectacularRedocView.as_view(url_name='schema'),   name='redoc'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
